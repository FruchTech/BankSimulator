package main;

import classes.Bank;

public class Main {

    public static void main(String[] args) {

        Bank b1 = new Bank();

    }
}